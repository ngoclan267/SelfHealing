#!/bin/bash
# ─────────────────────────────────────────────────────────────
# switch_ui.sh — Chuyển đổi UI version cho React app
#
# Dùng: bash src_mutated/switch_ui.sh [v1|v2|...|v11]
#
# Biến môi trường (tuỳ chọn):
#   SRC_DIR  — đường dẫn đến thư mục src/pages của React app
#              Mặc định: ../../myapp/src/pages (relative với script)
# ─────────────────────────────────────────────────────────────

VERSION=$1
if [ -z "$VERSION" ]; then
  echo "❌  Cần truyền version: v1|v2|...|v11"
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Ưu tiên biến môi trường, fallback về đường dẫn tương đối
if [ -n "$SRC_DIR" ]; then
  # Nếu SRC_DIR là đường dẫn tương đối, resolve từ CWD
  SRC_PAGES="$SRC_DIR"
else
  SRC_PAGES="$SCRIPT_DIR/../../myapp/src/pages"
fi

# Kiểm tra thư mục đích tồn tại
if [ ! -d "$SRC_PAGES" ]; then
  echo "❌  Không tìm thấy thư mục pages: $SRC_PAGES"
  echo "    Hãy đặt biến môi trường SRC_DIR trỏ đúng vào src/pages"
  exit 1
fi

echo "🔄  Đang chuyển sang UI $VERSION..."
echo "    Nguồn : $SCRIPT_DIR"
echo "    Đích  : $SRC_PAGES"

FILES=(Login Register Products Contact addProduct)

for FILE in "${FILES[@]}"; do
  SRC="$SCRIPT_DIR/${FILE}_${VERSION}.jsx"
  DST="$SRC_PAGES/${FILE}.jsx"

  if [ ! -f "$SRC" ]; then
    echo "⚠️   Bỏ qua (không tồn tại): $SRC"
    continue
  fi

  cp "$SRC" "$DST"
  echo "    ✅  $FILE.jsx → $VERSION"
done

echo "✅  Hoàn tất! Vite hot-reload sẽ tự cập nhật."
