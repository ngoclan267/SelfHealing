# 🚀 Hướng dẫn tích hợp GitHub Actions

## Cấu trúc project cần có trên GitHub

```
your-repo/
├── .github/
│   └── workflows/
│       ├── self-healing-tests.yml   ← workflow chính (toàn bộ UI v1–v11)
│       └── smoke-test.yml           ← workflow nhanh cho PR
│
├── myapp/                           ← React app (Vite)
│   ├── src/
│   │   └── pages/
│   │       ├── Login.jsx
│   │       ├── Register.jsx
│   │       ├── Products.jsx
│   │       ├── Contact.jsx
│   │       └── addProduct.jsx
│   ├── package.json
│   └── package-lock.json            ← cần có để npm ci chạy
│
├── src_mutated/                     ← các bản UI mutated
│   ├── switch_ui.sh
│   ├── Login_v1.jsx … Login_v11.jsx
│   ├── Register_v1.jsx …
│   ├── Products_v1.jsx …
│   ├── Contact_v1.jsx …
│   └── addProduct_v1.jsx …
│
├── core/                            ← Self-Healing engine
│   └── core/
│       ├── __init__.py
│       ├── Healing_driver_v2.py
│       ├── Similarity_engine_v2.py
│       ├── Exception_interceptor.py
│       ├── Snapshot.py
│       └── Logistic_weight_model.py
│
├── tests/                           ← Pytest test suite
│   └── tests/
│       ├── __init__.py
│       ├── conftest.py
│       ├── config.py
│       ├── test_login.py
│       ├── test_register.py
│       ├── test_products.py
│       ├── test_admin.py
│       ├── test_contact.py
│       └── test_self_healing.py
│
├── db_manager.py
├── requirements.txt
└── pytest.ini
```

---

## Bước 1: Đẩy code lên GitHub

```bash
git init
git remote add origin https://github.com/<user>/<repo>.git

# Copy tất cả files vào đúng cấu trúc trên rồi:
git add .
git commit -m "feat: add self-healing selenium test suite + CI"
git push -u origin main
```

---

## Bước 2: Workflow tự động chạy khi

| Sự kiện | Workflow |
|---------|----------|
| Push lên `main`/`develop` | `self-healing-tests.yml` (toàn bộ v1–v11) |
| Mở Pull Request | `smoke-test.yml` (chỉ v1, nhanh ~10–15 phút) |
| Kích thủ công | `self-healing-tests.yml` với tùy chọn version & module |

---

## Bước 3: Chạy thủ công (workflow_dispatch)

1. Vào tab **Actions** → chọn **Self-Healing Selenium Tests**
2. Click **Run workflow**
3. Chọn:
   - `ui_version`: `v1` / `v5` / `all` (mặc định: `all`)
   - `test_module`: `login` / `register` / `products` / `all` (mặc định: `all`)

---

## Xem kết quả

- **Tab Actions** → chọn run → xem log từng job
- **Artifacts**: HTML report + logs + `healing.db` cho mỗi UI version
- **PR Comments**: kết quả test được tự động comment vào PR

---

## Lưu ý quan trọng

### `config.py` — URL & credentials
File `tests/tests/config.py` hiện hardcode `localhost:5173`. Trong CI, React
chạy local nên không cần thay đổi.

Nếu muốn test môi trường staging, dùng **GitHub Secrets**:

```yaml
# Trong workflow:
env:
  BASE_URL: ${{ secrets.STAGING_URL }}
```

Thêm secret tại: **Settings → Secrets → Actions → New repository secret**

### Headless mode
File `conftest.py` hiện comment `--headless`. Trong CI **bắt buộc phải headless**.
Sửa `conftest.py`:

```python
opts.add_argument("--headless")   # ← bỏ comment
```

Hoặc thêm vào workflow:
```yaml
env:
  HEADLESS: "true"
```

Và trong `conftest.py`:
```python
if os.getenv("HEADLESS", "false").lower() == "true":
    opts.add_argument("--headless")
```

### `package-lock.json`
GitHub Actions dùng `npm ci` (cần `package-lock.json`). Nếu chưa có:

```bash
cd myapp && npm install   # tạo package-lock.json
git add package-lock.json
git commit -m "chore: add package-lock.json for CI"
```
