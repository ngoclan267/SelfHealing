import { useState, useEffect } from "react";
import axios from 'axios';
import { Link, useLocation, useNavigate } from 'react-router-dom';

// V12 Changes — ALL 5 DIMENSIONS:
//
// [Attribute]   - ALL data-testid removed
// [Attribute]   - Search input: data-qa removed; aria-label="Tìm kiếm sản phẩm" added
// [Attribute]   - Filter buttons: data-filter removed; aria-pressed={true/false} added
// [Attribute]   - Product cards: added aria-label on view/delete/edit buttons
// [Attribute]   - Admin add-product: no testid; has role="button" on Link implicitly
// [Attribute]   - Images: added loading="lazy" on product images
//
// [Semantic]    - h2 heading → h1 (single main heading per page)
// [Semantic]    - Filter buttons section: wrapped in <nav aria-label="Lọc sản phẩm">
// [Semantic]    - Product list: div.row → <ul> list with <li> items (semantic list)
// [Semantic]    - Product card: div.card → <article> element inside <li>
// [Semantic]    - Price: p.text-danger → <strong> with aria-label
// [Semantic]    - Loading state: div → <p role="status"> for accessibility
// [Semantic]    - Empty state: p → <p role="status"> element
// [Semantic]    - Delete button text: "Xóa" → "Xóa sản phẩm" (more descriptive)
//
// [Structure]   - Outer: div.container → <main> with nested <header> and <section>
// [Structure]   - Search: moved BELOW filter tabs (inverted order vs v1)
// [Structure]   - Admin add button: moved to top-right via absolute positioning in header
// [Structure]   - Product list: div.row → ul.product-grid (flat semantic list)
// [Structure]   - Each product: div.col-md-3 → li (semantic list item)
// [Structure]   - Edit and Delete buttons: now in a <footer> inside article (not raw div)
//
// [Visual]      - Page: white bg → slate dark (#1e2837) full-page dark mode
// [Visual]      - Search input: Bootstrap default → custom dark input with teal focus ring
// [Visual]      - Filter buttons: btn-dark/btn-outline-dark → custom pill with teal active
// [Visual]      - Product cards (article): Bootstrap card → dark glass-morphism card (#252f3e)
// [Visual]      - Product name: default → #e2e8f0 light text
// [Visual]      - Price: text-danger → #f6c90e (amber/gold color, different from red)
// [Visual]      - View button: btn-outline-dark → teal ghost button
// [Visual]      - Admin buttons: btn-danger → btn kept, btn-warning → different shade
//
// [Context]     - Page heading: "Danh sách sản phẩm" → "Cửa hàng sản phẩm Apple"
// [Context]     - Search placeholder: "Nhập tên sản phẩm cần tìm..." → "Tìm kiếm theo tên..."
// [Context]     - Category "Tất cả" → "Tất cả loại"
// [Context]     - "Chi tiết sản phẩm" → "Xem sản phẩm"
// [Context]     - Admin add button: "Thêm hàng mới" → "Thêm sản phẩm"
// [Context]     - Empty state: "Chưa có sản phẩm nào phù hợp." → "Không tìm thấy sản phẩm."
// [Context]     - Edit button: "Chỉnh sửa" → "Sửa"
// [Context]     - Loading text: "Đang tải sản phẩm..." → "Đang tải dữ liệu..."

const Products = () => {
    const [products, setProducts] = useState([]);
    const [allProducts, setAllProducts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState("");
    const navigate = useNavigate();
    const location = useLocation();
    const queryParams = new URLSearchParams(location.search);
    const typeFromUrl = queryParams.get('type') || "Tất cả loại";
    const [activeCategory, setActiveCategory] = useState(typeFromUrl);
    const [role, setRole] = useState(sessionStorage.getItem('role'));

    useEffect(() => {
        setRole(sessionStorage.getItem('role'));
        fetchProducts();
    }, []);

    const fetchProducts = () => {
        setLoading(true);
        axios.get("http://localhost:5000/api/products")
            .then(res => {
                if (Array.isArray(res.data)) {
                    setAllProducts(res.data);
                    applyFilter(res.data, activeCategory);
                }
                setLoading(false);
            })
            .catch(err => {
                console.error("Lỗi kết nối!", err);
                setLoading(false);
            });
    };

    const applyFilter = (data, category) => {
        if (category === 'Tất cả loại') setProducts(data);
        else setProducts(data.filter(p => p.category === category));
    };

    const handleFilter = (category) => {
        setActiveCategory(category);
        applyFilter(allProducts, category);
    };

    const handleDelete = async (category, id) => {
        if (window.confirm("Bạn có chắc muốn xóa sản phẩm này?")) {
            const token = sessionStorage.getItem('token');
            try {
                await axios.delete(`http://localhost:5000/api/products/${category}/${id}`, {
                    headers: { Authorization: `Bearer ${token}` }
                });
                alert("Xóa thành công!");
                fetchProducts();
            } catch (err) {
                alert(err.response?.data?.message || "Lỗi khi xóa");
            }
        }
    };

    const searchedProducts = products.filter(p =>
        p.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    // Styles
    const pageStyle = {
        background: '#1e2837',
        minHeight: '100vh',
        padding: '32px 20px',
        color: '#e2e8f0'
    };

    const searchStyle = {
        background: '#252f3e',
        border: '1px solid #3d4f63',
        color: '#e2e8f0',
        borderRadius: '50px',
        padding: '10px 22px',
        width: '100%',
        fontSize: '0.94rem',
        outline: 'none'
    };

    const cardStyle = {
        background: '#252f3e',
        border: '1px solid #3d4f63',
        borderRadius: '12px',
        overflow: 'hidden',
        height: '100%',
        display: 'flex',
        flexDirection: 'column'
    };

    const categories = ['Tất cả loại', 'iphone', 'ipad', 'macbook', 'airpods'];

    if (loading) return (
        <main style={pageStyle}>
            <p role="status" style={{ textAlign: 'center', marginTop: '80px', color: '#8892b0' }}>
                Đang tải dữ liệu...
            </p>
        </main>
    );

    return (
        <main style={pageStyle}>
            <header style={{ position: 'relative', textAlign: 'center', marginBottom: '28px' }}>
                <h1 style={{ fontSize: '1.8rem', fontWeight: 800, color: '#e2e8f0' }}>
                    Cửa hàng sản phẩm Apple
                </h1>
                {role === 'admin' && (
                    <div style={{ position: 'absolute', right: 0, top: 0 }}>
                        <Link
                            to="/admin/add-product"
                            aria-label="Thêm sản phẩm mới vào danh sách"
                            style={{
                                background: '#64ffda',
                                color: '#0d1b2a',
                                textDecoration: 'none',
                                padding: '8px 20px',
                                borderRadius: '6px',
                                fontWeight: 700,
                                fontSize: '0.9rem'
                            }}
                        >
                            Thêm sản phẩm
                        </Link>
                    </div>
                )}
            </header>

            {/* Filter tabs — moved ABOVE search (structure change) */}
            <nav aria-label="Lọc sản phẩm" style={{ display: 'flex', justifyContent: 'center', gap: '10px', marginBottom: '20px', flexWrap: 'wrap' }}>
                {categories.map(cat => (
                    <button
                        key={cat}
                        aria-pressed={activeCategory === cat}
                        onClick={() => handleFilter(cat)}
                        style={{
                            padding: '8px 20px',
                            borderRadius: '50px',
                            border: activeCategory === cat ? 'none' : '1px solid #3d4f63',
                            background: activeCategory === cat ? '#64ffda' : 'transparent',
                            color: activeCategory === cat ? '#0d1b2a' : '#8892b0',
                            fontWeight: activeCategory === cat ? 700 : 400,
                            cursor: 'pointer',
                            fontSize: '0.88rem',
                            transition: 'all 0.2s'
                        }}
                    >
                        {cat === 'Tất cả loại' ? 'TẤT CẢ' : cat.toUpperCase()}
                    </button>
                ))}
            </nav>

            {/* Search — moved BELOW filter (structure inversion) */}
            <section style={{ display: 'flex', justifyContent: 'center', marginBottom: '32px' }}>
                <div style={{ width: '100%', maxWidth: '440px' }}>
                    <input
                        type="text"
                        aria-label="Tìm kiếm sản phẩm"
                        placeholder="Tìm kiếm theo tên..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        style={searchStyle}
                    />
                </div>
            </section>

            {/* Product list as <ul> */}
            {searchedProducts.length > 0 ? (
                <ul
                    style={{
                        display: 'grid',
                        gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))',
                        gap: '20px',
                        listStyle: 'none',
                        padding: 0,
                        margin: 0
                    }}
                >
                    {searchedProducts.map(p => (
                        <li key={p._id}>
                            <article style={cardStyle}>
                                <img
                                    src={p.image || (p.variants && p.variants[0]?.img) || "https://via.placeholder.com/150"}
                                    alt={p.name}
                                    loading="lazy"
                                    style={{
                                        height: '180px',
                                        objectFit: 'contain',
                                        padding: '16px',
                                        background: '#1e2837'
                                    }}
                                />
                                <div style={{ padding: '16px', flex: 1, textAlign: 'center' }}>
                                    <h2 style={{ fontSize: '0.95rem', fontWeight: 700, color: '#e2e8f0', marginBottom: '6px' }}>
                                        {p.name}
                                    </h2>
                                    <strong
                                        aria-label={`Giá: ${Number(p.pr || p.price).toLocaleString()} VND`}
                                        style={{ color: '#f6c90e', display: 'block', marginBottom: '12px', fontSize: '0.95rem' }}
                                    >
                                        {Number(p.pr || p.price).toLocaleString()} VND
                                    </strong>
                                    <Link
                                        to={`/product/${p.category}/${p._id}`}
                                        aria-label={`Xem sản phẩm ${p.name}`}
                                        style={{
                                            display: 'block',
                                            border: '1px solid #64ffda',
                                            color: '#64ffda',
                                            borderRadius: '50px',
                                            padding: '7px 0',
                                            textDecoration: 'none',
                                            fontSize: '0.85rem',
                                            fontWeight: 600
                                        }}
                                    >
                                        Xem sản phẩm
                                    </Link>
                                </div>
                                {role === 'admin' && (
                                    <footer style={{ display: 'flex', gap: '8px', padding: '0 16px 16px' }}>
                                        <button
                                            onClick={() => handleDelete(p.category, p._id)}
                                            aria-label={`Xóa sản phẩm ${p.name}`}
                                            className="btn btn-danger btn-sm flex-fill"
                                            style={{ borderRadius: '50px' }}
                                        >
                                            Xóa sản phẩm
                                        </button>
                                        <button
                                            onClick={() => navigate(`/edit-product/${p.category}/${p._id}`)}
                                            aria-label={`Sửa sản phẩm ${p.name}`}
                                            className="btn btn-warning btn-sm flex-fill"
                                            style={{ borderRadius: '50px' }}
                                        >
                                            Sửa
                                        </button>
                                    </footer>
                                )}
                            </article>
                        </li>
                    ))}
                </ul>
            ) : (
                <p role="status" style={{ textAlign: 'center', marginTop: '60px', color: '#8892b0' }}>
                    Không tìm thấy sản phẩm.
                </p>
            )}
        </main>
    );
};

export default Products;