import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

// V12 Changes — ALL 5 DIMENSIONS:
//
// [Attribute]   - ALL data-testid removed
// [Attribute]   - data-id attributes (from v11 approach) not used; aria-label used instead on key inputs
// [Attribute]   - Remove buttons: got aria-label="Xóa dòng này" 
// [Attribute]   - Add buttons: got aria-label descriptive text
// [Attribute]   - Submit button: type="submit" → kept; aria-label="Đăng sản phẩm" added
// [Attribute]   - Select: added aria-required="true"
// [Attribute]   - Image input: name changed "image" → "coverImage"
//
// [Semantic]    - h2 heading → h1 for page title
// [Semantic]    - Section elements kept; but <h5> → <h4> inside each section
// [Semantic]    - Remove buttons text: "×" → "Xóa" (more descriptive)
// [Semantic]    - Add buttons text changed to more semantic Vietnamese
// [Semantic]    - Submit button text: "XÁC NHẬN ĐĂNG SẢN PHẨM" → "Đăng sản phẩm"
// [Semantic]    - Price input: type="number" kept; added min="0" attribute
// [Semantic]    - Description: textarea element (was already textarea in v1, kept)
//
// [Structure]   - Outer wrapper: div.container → <main> element with same styles
// [Structure]   - Form sections restructured: section → <details open> with <summary> as heading
// [Structure]   - Each spec/gb/variant row: div.row → div with custom grid via inline style
// [Structure]   - Submit button moved OUTSIDE the form, linked via form="add-product-form"
// [Structure]   - Form: given id="add-product-form"
// [Structure]   - Section 3 and 4 swapped (Variants before GB — different order)
//
// [Visual]      - Background: '#f5f6fa' → deep navy '#0d1b2a' (dark mode entire page)
// [Visual]      - Form card: white → '#112240' dark card, white text
// [Visual]      - Section headings: dark text → accent teal (#64ffda)
// [Visual]      - Inputs: default Bootstrap → dark themed (bg:#0a192f, text:#ccd6f6, border:#233554)
// [Visual]      - Remove buttons: btn-outline-danger → small red icon-like button
// [Visual]      - Add buttons: btn-outline-secondary → teal ghost button
// [Visual]      - Submit: btn-primary → solid teal button (#64ffda, dark text)
// [Visual]      - Labels: dark→ #8892b0 (muted slate)
//
// [Context]     - Page heading: "Đăng sản phẩm lên hệ thống" → "Thêm sản phẩm mới vào kho"
// [Context]     - Section 1: "Thông tin chung" → "Thông tin định danh"
// [Context]     - Label name: "Tên hàng hóa" → "Tên sản phẩm"
// [Context]     - Label category: "Loại sản phẩm" → "Danh mục"
// [Context]     - Label price: "Giá bán" → "Giá niêm yết (VND)"
// [Context]     - Section 2: "Chi tiết kỹ thuật" → "Thông số & Đặc điểm"
// [Context]     - Section 3 (now Variants): "Phiên bản màu" → "Màu sắc & Ảnh"
// [Context]     - Section 4 (now GB): "Tùy chọn bộ nhớ" → "Cấu hình & Giá"
// [Context]     - Spec placeholders: more descriptive (e.g. "VD: Chip", "VD: A18 Pro")
// [Context]     - Image placeholder: "URL hình ảnh đại diện" → "Link ảnh bìa sản phẩm"

const AddProduct = () => {
    const navigate = useNavigate();
    const [product, setProduct] = useState({
        name: "",
        description: "",
        pr: 0,
        category: "iphone",
        image: "",
        specifications: [{ key: "", value: "" }],
        Gb: [{ label: "", price: 0 }],
        variants: [{ colorName: "", colorCode: "", img: "" }]
    });

    const handleChange = (e) => {
        setProduct({ ...product, [e.target.name]: e.target.value });
    };

    const handleArrayChange = (index, field, subField, value) => {
        setProduct(prev => {
            const arr = [...prev[field]];
            arr[index] = { ...arr[index], [subField]: value };
            return { ...prev, [field]: arr };
        });
    };

    const addField = (field, defaultValue) => {
        setProduct({ ...product, [field]: [...product[field], defaultValue] });
    };

    const removeField = (field, index) => {
        setProduct({ ...product, [field]: product[field].filter((_, i) => i !== index) });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const token = sessionStorage.getItem('token');
        const cleanSpecifications = product.specifications.filter(
            s => s.key.trim() && s.value.trim()
        );
        const finalImage = Array.isArray(product.image) ? product.image : [product.image];
        const dataToSend = { ...product, specifications: cleanSpecifications, image: finalImage };

        try {
            await axios.post(`http://localhost:5000/api/products/${product.category}`, dataToSend, {
                headers: { Authorization: `Bearer ${token}` }
            });
            alert("Thêm sản phẩm thành công!");
            navigate("/");
        } catch (err) {
            alert(err.response?.data?.message || "Lỗi khi thêm sản phẩm");
        }
    };

    // Dark theme styles
    const pageStyle = {
        background: '#0d1b2a',
        minHeight: '100vh',
        padding: '32px 20px'
    };

    const cardStyle = {
        background: '#112240',
        borderRadius: '16px',
        padding: '36px',
        boxShadow: '0 10px 40px rgba(0,0,0,0.4)',
        maxWidth: '860px',
        margin: '0 auto'
    };

    const inputStyle = {
        background: '#0a192f',
        border: '1px solid #233554',
        color: '#ccd6f6',
        borderRadius: '6px',
        padding: '9px 12px',
        width: '100%',
        fontSize: '0.92rem',
        outline: 'none'
    };

    const labelStyle = {
        display: 'block',
        fontSize: '0.82rem',
        color: '#8892b0',
        marginBottom: '5px',
        fontWeight: 600
    };

    const sectionHeadingStyle = {
        color: '#64ffda',
        fontSize: '0.95rem',
        fontWeight: 700,
        textTransform: 'uppercase',
        letterSpacing: '0.8px',
        marginBottom: '16px',
        paddingBottom: '8px',
        borderBottom: '1px solid #233554'
    };

    const removeBtnStyle = {
        background: 'transparent',
        border: '1px solid #e74c3c',
        color: '#e74c3c',
        borderRadius: '4px',
        padding: '6px 10px',
        cursor: 'pointer',
        fontSize: '0.8rem'
    };

    const addBtnStyle = {
        background: 'transparent',
        border: '1px solid #64ffda',
        color: '#64ffda',
        borderRadius: '4px',
        padding: '6px 14px',
        cursor: 'pointer',
        fontSize: '0.82rem',
        marginTop: '8px'
    };

    const submitBtnStyle = {
        background: '#64ffda',
        color: '#0d1b2a',
        border: 'none',
        borderRadius: '8px',
        padding: '14px 0',
        width: '100%',
        fontWeight: 800,
        fontSize: '1rem',
        cursor: 'pointer',
        letterSpacing: '0.5px',
        marginTop: '24px'
    };

    const rowStyle = {
        display: 'grid',
        gap: '10px',
        marginBottom: '10px',
        alignItems: 'center'
    };

    return (
        <main style={pageStyle}>
            <h1 style={{ textAlign: 'center', color: '#ccd6f6', fontWeight: 800, marginBottom: '28px', fontSize: '1.6rem' }}>
                Thêm sản phẩm mới vào kho
            </h1>

            <div style={cardStyle}>
                <form id="add-product-form" onSubmit={handleSubmit}>

                    {/* Section 1: Thông tin định danh */}
                    <details open style={{ marginBottom: '28px' }}>
                        <summary style={{ ...sectionHeadingStyle, cursor: 'pointer', listStyle: 'none' }}>
                            1. Thông tin định danh
                        </summary>
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginTop: '16px' }}>
                            <div>
                                <label style={labelStyle}>Tên sản phẩm</label>
                                <input
                                    type="text"
                                    name="name"
                                    aria-label="Nhập tên sản phẩm"
                                    required
                                    onChange={handleChange}
                                    placeholder="VD: iPhone 16 Pro Max"
                                    style={inputStyle}
                                />
                            </div>
                            <div>
                                <label style={labelStyle}>Danh mục</label>
                                <select
                                    name="category"
                                    aria-required="true"
                                    onChange={handleChange}
                                    style={{ ...inputStyle, cursor: 'pointer' }}
                                >
                                    <option value="iphone">iPhone</option>
                                    <option value="ipad">iPad</option>
                                    <option value="macbook">Macbook</option>
                                    <option value="airpods">Airpods</option>
                                </select>
                            </div>
                            <div>
                                <label style={labelStyle}>Giá niêm yết (VND)</label>
                                <input
                                    type="number"
                                    name="pr"
                                    aria-label="Giá sản phẩm"
                                    min="0"
                                    required
                                    onChange={handleChange}
                                    style={inputStyle}
                                />
                            </div>
                            <div>
                                <label style={labelStyle}>Link ảnh bìa sản phẩm</label>
                                <input
                                    type="text"
                                    name="coverImage"
                                    aria-label="URL hình ảnh sản phẩm"
                                    placeholder="https://..."
                                    onChange={(e) => setProduct({ ...product, image: e.target.value })}
                                    style={inputStyle}
                                />
                            </div>
                            <div style={{ gridColumn: '1 / -1' }}>
                                <label style={labelStyle}>Mô tả sản phẩm</label>
                                <textarea
                                    name="description"
                                    rows="3"
                                    onChange={handleChange}
                                    style={{ ...inputStyle, resize: 'vertical' }}
                                />
                            </div>
                        </div>
                    </details>

                    {/* Section 2: Thông số & Đặc điểm */}
                    <details open style={{ marginBottom: '28px' }}>
                        <summary style={{ ...sectionHeadingStyle, cursor: 'pointer', listStyle: 'none' }}>
                            2. Thông số & Đặc điểm
                        </summary>
                        <div style={{ marginTop: '16px' }}>
                            {product.specifications.map((spec, index) => (
                                <div key={index} style={{ ...rowStyle, gridTemplateColumns: '1fr 1fr auto' }}>
                                    <input
                                        type="text"
                                        placeholder="VD: Chip"
                                        aria-label={`Tên thuộc tính ${index + 1}`}
                                        value={spec.key}
                                        onChange={(e) => handleArrayChange(index, 'specifications', 'key', e.target.value)}
                                        style={inputStyle}
                                    />
                                    <input
                                        type="text"
                                        placeholder="VD: A18 Pro"
                                        aria-label={`Giá trị thuộc tính ${index + 1}`}
                                        value={spec.value}
                                        onChange={(e) => handleArrayChange(index, 'specifications', 'value', e.target.value)}
                                        style={inputStyle}
                                    />
                                    <button
                                        type="button"
                                        aria-label="Xóa dòng này"
                                        onClick={() => removeField('specifications', index)}
                                        style={removeBtnStyle}
                                    >
                                        Xóa
                                    </button>
                                </div>
                            ))}
                            <button
                                type="button"
                                aria-label="Thêm thông số kỹ thuật mới"
                                onClick={() => addField('specifications', { key: "", value: "" })}
                                style={addBtnStyle}
                            >
                                + Thêm thông số
                            </button>
                        </div>
                    </details>

                    {/* Section 3 (SWAPPED): Màu sắc & Ảnh */}
                    <details open style={{ marginBottom: '28px' }}>
                        <summary style={{ ...sectionHeadingStyle, cursor: 'pointer', listStyle: 'none' }}>
                            3. Màu sắc & Ảnh
                        </summary>
                        <div style={{ marginTop: '16px' }}>
                            {product.variants.map((variant, index) => (
                                <div key={index} style={{ ...rowStyle, gridTemplateColumns: '1fr 80px 1fr auto' }}>
                                    <input
                                        type="text"
                                        placeholder="Tên màu (Đen, Trắng...)"
                                        aria-label={`Tên màu ${index + 1}`}
                                        onChange={(e) => handleArrayChange(index, 'variants', 'colorName', e.target.value)}
                                        style={inputStyle}
                                    />
                                    <input
                                        type="color"
                                        aria-label={`Mã màu hex ${index + 1}`}
                                        onChange={(e) => handleArrayChange(index, 'variants', 'colorCode', e.target.value)}
                                        style={{ ...inputStyle, padding: '4px', height: '38px', cursor: 'pointer' }}
                                    />
                                    <input
                                        type="text"
                                        placeholder="Link ảnh màu này"
                                        aria-label={`Ảnh màu ${index + 1}`}
                                        onChange={(e) => handleArrayChange(index, 'variants', 'img', e.target.value)}
                                        style={inputStyle}
                                    />
                                    <button
                                        type="button"
                                        aria-label="Xóa màu này"
                                        onClick={() => removeField('variants', index)}
                                        style={removeBtnStyle}
                                    >
                                        Xóa
                                    </button>
                                </div>
                            ))}
                            <button
                                type="button"
                                aria-label="Thêm phiên bản màu mới"
                                onClick={() => addField('variants', { colorName: "", colorCode: "", img: "" })}
                                style={addBtnStyle}
                            >
                                + Thêm màu
                            </button>
                        </div>
                    </details>

                    {/* Section 4 (SWAPPED): Cấu hình & Giá */}
                    <details open style={{ marginBottom: '16px' }}>
                        <summary style={{ ...sectionHeadingStyle, cursor: 'pointer', listStyle: 'none' }}>
                            4. Cấu hình & Giá
                        </summary>
                        <div style={{ marginTop: '16px' }}>
                            {product.Gb.map((item, index) => (
                                <div key={index} style={{ ...rowStyle, gridTemplateColumns: '1fr 1fr auto' }}>
                                    <input
                                        type="text"
                                        placeholder="Cấu hình (128GB, 256GB...)"
                                        aria-label={`Dung lượng ${index + 1}`}
                                        onChange={(e) => handleArrayChange(index, 'Gb', 'label', e.target.value)}
                                        style={inputStyle}
                                    />
                                    <input
                                        type="number"
                                        placeholder="Giá cho cấu hình này"
                                        aria-label={`Giá dung lượng ${index + 1}`}
                                        min="0"
                                        onChange={(e) => handleArrayChange(index, 'Gb', 'price', e.target.value)}
                                        style={inputStyle}
                                    />
                                    <button
                                        type="button"
                                        aria-label="Xóa cấu hình này"
                                        onClick={() => removeField('Gb', index)}
                                        style={removeBtnStyle}
                                    >
                                        Xóa
                                    </button>
                                </div>
                            ))}
                            <button
                                type="button"
                                aria-label="Thêm tùy chọn cấu hình mới"
                                onClick={() => addField('Gb', { label: "", price: 0 })}
                                style={addBtnStyle}
                            >
                                + Thêm cấu hình
                            </button>
                        </div>
                    </details>
                </form>

                {/* Submit OUTSIDE form, linked via form attribute */}
                <button
                    type="submit"
                    form="add-product-form"
                    aria-label="Đăng sản phẩm"
                    style={submitBtnStyle}
                >
                    Đăng sản phẩm
                </button>
            </div>
        </main>
    );
};

export default AddProduct;