import { useState } from "react";
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';

// V12 Changes — ALL 5 DIMENSIONS:
//
// [Attribute]   - ALL data-testid removed; aria-label added on inputs
// [Attribute]   - name="email", name="password" added
// [Attribute]   - autocomplete="email" / "new-password" added
// [Attribute]   - form: added noValidate; id="register-form" added to form
// [Attribute]   - button: no id/testid; added aria-label="Tạo tài khoản mới"
//
// [Semantic]    - h3 → h1 for register heading (more correct top-level heading)
// [Semantic]    - Email error: div.invalid-feedback → <span role="alert"> inline
// [Semantic]    - Register button text: "Đăng ký" → "Tạo tài khoản"
// [Semantic]    - Footer: <small> → <p className="text-muted small"> (semantic change)
// [Semantic]    - Added <main> wrapper around card for semantic landmark
// [Semantic]    - Label htmlFor now correctly paired with input IDs
//
// [Structure]   - Outer layout: "container mt-5" → full-screen flex layout (no container)
// [Structure]   - Card inner: div.card-body → article element
// [Structure]   - Inputs: moved from div.mb-3 → div.field-row (custom class)
// [Structure]   - Error span is now INSIDE the input wrapper div, after input (not separate div)
// [Structure]   - Footer text now ABOVE the submit button (position flipped)
// [Structure]   - Heading and subtitle in a dedicated <header> element inside card
//
// [Visual]      - Entire page: white/gradient → split-panel layout (left decorative, right form)
// [Visual]      - Left panel (desktop): solid colored panel with brand name (hidden on mobile)
// [Visual]      - Form panel: clean white, no border-radius on outer, only inner card
// [Visual]      - Button: btn-success → custom styled (indigo, full-width, no rounded-pill)
// [Visual]      - Input focus: normal → highlighted with box-shadow (via inline class fallback)
// [Visual]      - Typography: default → Lato import via inline style (font-family declared)
//
// [Context]     - Heading: "Đăng ký tài khoản" → "Bắt đầu miễn phí"
// [Context]     - Subtitle: added "Tạo tài khoản để mua sắm dễ dàng hơn"
// [Context]     - Email label: "Email" → "Email đăng ký"
// [Context]     - Password label: "Mật khẩu" → "Mật khẩu (tối thiểu 6 ký tự)"
// [Context]     - Email placeholder: "name@example.com" → "Nhập email của bạn"
// [Context]     - Password placeholder: "••••••••" → "Tạo mật khẩu mạnh"
// [Context]     - Footer: "Đã có tài khoản?" → "Bạn đã có tài khoản?"
// [Context]     - Login link: "Đăng nhập" → "Đăng nhập ngay"

const Register = () => {
    const [user, setUser] = useState({ email: '', password: '', role: 'user' });
    const [emailError, setEmailError] = useState('');
    const navigate = useNavigate();

    const validateEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

    const handleEmailChange = (e) => {
        const val = e.target.value;
        setUser({ ...user, email: val });
        setEmailError(val && !validateEmail(val) ? 'Email không hợp lệ!' : '');
    };

    const handleRegister = async (e) => {
        e.preventDefault();
        if (!validateEmail(user.email)) {
            setEmailError('Vui lòng nhập đúng định dạng email!');
            return;
        }
        try {
            const res = await axios.post('http://localhost:5000/api/auth/register', user);
            alert(res.data.message || "Đăng ký thành công!");
            navigate('/login');
        } catch (err) {
            console.error(err);
            alert(err.response?.data?.message || "Đăng ký thất bại, email có thể đã tồn tại!");
        }
    };

    const panelStyle = {
        display: 'flex',
        minHeight: '100vh',
        fontFamily: "'Lato', 'Segoe UI', sans-serif"
    };

    const leftPanelStyle = {
        flex: '0 0 40%',
        background: 'linear-gradient(160deg, #6c5ce7 0%, #a29bfe 100%)',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        color: '#fff',
        padding: '40px'
    };

    const rightPanelStyle = {
        flex: 1,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: '#f8f9fa',
        padding: '40px 20px'
    };

    const formCardStyle = {
        width: '100%',
        maxWidth: '400px',
        background: '#fff',
        borderRadius: '12px',
        padding: '40px 36px',
        boxShadow: '0 4px 24px rgba(108,92,231,0.10)'
    };

    const fieldRowStyle = { marginBottom: '20px' };

    const labelStyle = {
        display: 'block',
        fontSize: '0.85rem',
        fontWeight: 600,
        marginBottom: '6px',
        color: '#444'
    };

    const inputStyle = {
        width: '100%',
        border: '1.5px solid #dfe6e9',
        borderRadius: '6px',
        padding: '10px 12px',
        fontSize: '0.94rem',
        outline: 'none'
    };

    const btnStyle = {
        width: '100%',
        background: '#6c5ce7',
        color: '#fff',
        border: 'none',
        borderRadius: '6px',
        padding: '12px 0',
        fontWeight: 700,
        fontSize: '1rem',
        cursor: 'pointer',
        letterSpacing: '0.3px'
    };

    return (
        <div style={panelStyle}>
            {/* Left decorative panel */}
            <div style={leftPanelStyle} className="d-none d-md-flex">
                <h2 style={{ fontWeight: 800, fontSize: '2rem', marginBottom: '12px' }}>AppleStore</h2>
                <p style={{ opacity: 0.85, textAlign: 'center', lineHeight: 1.6 }}>
                    Mua sắm chính hãng<br />Trải nghiệm đẳng cấp
                </p>
            </div>

            {/* Right form panel */}
            <main style={rightPanelStyle}>
                <article style={formCardStyle}>
                    <header style={{ marginBottom: '28px', textAlign: 'center' }}>
                        <h1 style={{ fontSize: '1.55rem', fontWeight: 800, color: '#2d3436', marginBottom: '6px' }}>
                            Bắt đầu miễn phí
                        </h1>
                        <p style={{ fontSize: '0.87rem', color: '#636e72', margin: 0 }}>
                            Tạo tài khoản để mua sắm dễ dàng hơn
                        </p>
                    </header>

                    <form id="register-form" onSubmit={handleRegister} noValidate>

                        {/* Email field */}
                        <div className="field-row" style={fieldRowStyle}>
                            <label htmlFor="input-email" style={labelStyle}>Email đăng ký</label>
                            <input
                                type="email"
                                id="input-email"
                                name="email"
                                aria-label="Nhập địa chỉ email để đăng ký"
                                autoComplete="email"
                                placeholder="Nhập email của bạn"
                                required
                                value={user.email}
                                onChange={handleEmailChange}
                                style={inputStyle}
                            />
                            {emailError && (
                                <span
                                    role="alert"
                                    style={{ color: '#d63031', fontSize: '0.82rem', marginTop: '4px', display: 'block' }}
                                >
                                    {emailError}
                                </span>
                            )}
                        </div>

                        {/* Password field */}
                        <div className="field-row" style={fieldRowStyle}>
                            <label htmlFor="input-password" style={labelStyle}>
                                Mật khẩu (tối thiểu 6 ký tự)
                            </label>
                            <input
                                type="password"
                                id="input-password"
                                name="password"
                                aria-label="Tạo mật khẩu cho tài khoản"
                                autoComplete="new-password"
                                placeholder="Tạo mật khẩu mạnh"
                                required
                                onChange={e => setUser({ ...user, password: e.target.value })}
                                style={inputStyle}
                            />
                        </div>

                        {/* Footer ABOVE button (structure inversion) */}
                        <p className="text-muted small" style={{ textAlign: 'center', marginBottom: '14px' }}>
                            Bạn đã có tài khoản?{' '}
                            <Link to="/login" style={{ color: '#6c5ce7', textDecoration: 'none', fontWeight: 600 }}>
                                Đăng nhập ngay
                            </Link>
                        </p>

                        <button
                            type="submit"
                            aria-label="Tạo tài khoản mới"
                            style={btnStyle}
                        >
                            Tạo tài khoản
                        </button>
                    </form>
                </article>
            </main>
        </div>
    );
};

export default Register;