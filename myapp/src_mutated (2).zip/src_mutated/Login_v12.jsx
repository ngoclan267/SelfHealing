import { useState } from "react";
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';

// V12 Changes — ALL 5 DIMENSIONS:
//
// [Attribute]   - ALL data-testid removed; replaced with aria-label on key elements
// [Attribute]   - type="email" → type="text" on email input (still validates with regex)
// [Attribute]   - name="email" and name="password" attributes added
// [Attribute]   - autocomplete="username" / "current-password" added
// [Attribute]   - form: added noValidate attribute
// [Attribute]   - button type="submit" kept but id removed
//
// [Semantic]    - Heading role: h3 → h2 (semantic hierarchy change)
// [Semantic]    - Form submission button text: "Đăng nhập" → "Xác nhận đăng nhập"
// [Semantic]    - Error message rendered in <p> with role="alert" instead of <div class="invalid-feedback">
// [Semantic]    - Footer link: <a href=""> → <Link to=""> (react-router)
// [Semantic]    - Password label: "Mật khẩu" → "Mật khẩu bảo mật"
// [Semantic]    - Added <fieldset> wrapping all inputs for better semantic grouping
// [Semantic]    - Added <legend> inside fieldset (visually hidden)
//
// [Structure]   - Outer layout: removed "container mt-5"; restructured to flex centering div
// [Structure]   - Card structure: moved from div.card > div.card-body → section > div (flat card)
// [Structure]   - Moved footer link ABOVE the submit button (different sibling order)
// [Structure]   - Error message now sibling of input (not child of wrapper div)
// [Structure]   - Parent of inputs changed from div.mb-3 → div.form-group (class change)
// [Structure]   - Added wrapper <div className="input-wrapper"> around each label+input pair
//
// [Visual]      - Background: solid color → radial gradient
// [Visual]      - Card: white bg → dark card (#1a1a2e), white text; inverted color scheme
// [Visual]      - Inputs: dark bg (#16213e), light text, custom border color
// [Visual]      - Button: btn-primary → custom inline style (green bg, white text, full rounded)
// [Visual]      - Heading color: white on dark bg; font size 1.6rem
// [Visual]      - Layout: card centered with fixed width 380px, no maxWidth
//
// [Context]     - Page title/heading: "Đăng nhập" → "Chào mừng trở lại"
// [Context]     - Subtitle added: "Đăng nhập để tiếp tục trải nghiệm mua sắm"
// [Context]     - Email label: "Email" → "Tài khoản Email"
// [Context]     - Placeholder email: "name@example.com" → "Tài khoản đăng ký của bạn"
// [Context]     - Placeholder password: "••••••••" → "Mật khẩu của bạn"
// [Context]     - Footer text: "Bạn chưa có tài khoản?" → "Chưa có tài khoản?"
// [Context]     - Register link text: "Đăng ký ngay" → "Đăng ký miễn phí"

const Login = () => {
    const [user, setUser] = useState({ email: '', password: '' });
    const [emailError, setEmailError] = useState('');
    const navigate = useNavigate();

    const validateEmail = (email) => {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    };

    const handleEmailChange = (e) => {
        const val = e.target.value;
        setUser({ ...user, email: val });
        if (val && !validateEmail(val)) {
            setEmailError('Email không đúng định dạng!');
        } else {
            setEmailError('');
        }
    };

    const handleLogin = async (e) => {
        e.preventDefault();
        if (!validateEmail(user.email)) {
            setEmailError('Vui lòng nhập đúng định dạng email');
            return;
        }
        try {
            const res = await axios.post('http://localhost:5000/api/auth/login', user);
            sessionStorage.setItem('token', res.data.token);
            sessionStorage.setItem('role', res.data.role);
            alert("Đăng nhập thành công!");
            window.location.href = "/";
        } catch (err) {
            console.error(err);
            alert(err.response?.data?.message || "Đăng nhập thất bại!");
        }
    };

    const cardStyle = {
        width: '380px',
        background: '#1a1a2e',
        borderRadius: '16px',
        padding: '36px 32px',
        boxShadow: '0 12px 40px rgba(0,0,0,0.35)',
        color: '#fff'
    };

    const inputStyle = {
        background: '#16213e',
        border: '1px solid #0f3460',
        color: '#e0e0e0',
        borderRadius: '8px',
        padding: '10px 14px',
        width: '100%',
        fontSize: '0.94rem',
        outline: 'none'
    };

    const btnStyle = {
        background: '#00b894',
        color: '#fff',
        border: 'none',
        borderRadius: '50px',
        padding: '12px 0',
        width: '100%',
        fontWeight: 700,
        fontSize: '1rem',
        cursor: 'pointer',
        letterSpacing: '0.5px',
        marginTop: '8px'
    };

    return (
        <div style={{
            minHeight: '100vh',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            background: 'radial-gradient(ellipse at 60% 40%, #0f3460 0%, #16213e 60%, #0a0a1a 100%)'
        }}>
            <section style={cardStyle}>
                <h2 style={{ textAlign: 'center', fontSize: '1.6rem', marginBottom: '6px', color: '#fff' }}>
                    Chào mừng trở lại
                </h2>
                <p style={{ textAlign: 'center', color: '#aab', fontSize: '0.87rem', marginBottom: '28px' }}>
                    Đăng nhập để tiếp tục trải nghiệm mua sắm
                </p>

                <form onSubmit={handleLogin} noValidate>
                    <fieldset style={{ border: 'none', padding: 0, margin: 0 }}>
                        <legend style={{ position: 'absolute', width: '1px', height: '1px', overflow: 'hidden', clip: 'rect(0,0,0,0)' }}>
                            Thông tin đăng nhập
                        </legend>

                        {/* Email */}
                        <div className="form-group" style={{ marginBottom: '18px' }}>
                            <div className="input-wrapper">
                                <label
                                    htmlFor="email-input"
                                    style={{ display: 'block', marginBottom: '6px', fontSize: '0.85rem', color: '#ccd' }}
                                >
                                    Tài khoản Email
                                </label>
                                <input
                                    type="text"
                                    id="email-input"
                                    name="email"
                                    aria-label="Nhập địa chỉ email đăng nhập"
                                    autoComplete="username"
                                    placeholder="Tài khoản đăng ký của bạn"
                                    required
                                    value={user.email}
                                    onChange={handleEmailChange}
                                    style={inputStyle}
                                />
                            </div>
                            {emailError && (
                                <p
                                    role="alert"
                                    style={{ color: '#ff6b6b', fontSize: '0.82rem', marginTop: '4px', marginBottom: 0 }}
                                >
                                    {emailError}
                                </p>
                            )}
                        </div>

                        {/* Password */}
                        <div className="form-group" style={{ marginBottom: '24px' }}>
                            <div className="input-wrapper">
                                <label
                                    htmlFor="password-input"
                                    style={{ display: 'block', marginBottom: '6px', fontSize: '0.85rem', color: '#ccd' }}
                                >
                                    Mật khẩu bảo mật
                                </label>
                                <input
                                    type="password"
                                    id="password-input"
                                    name="password"
                                    aria-label="Nhập mật khẩu đăng nhập"
                                    autoComplete="current-password"
                                    placeholder="Mật khẩu của bạn"
                                    required
                                    onChange={e => setUser({ ...user, password: e.target.value })}
                                    style={inputStyle}
                                />
                            </div>
                        </div>
                    </fieldset>

                    {/* Footer link ABOVE button (structure change) */}
                    <div style={{ textAlign: 'center', marginBottom: '14px' }}>
                        <small style={{ color: '#99a' }}>
                            Chưa có tài khoản?{' '}
                            <Link to="/register" style={{ color: '#00cec9', textDecoration: 'none' }}>
                                Đăng ký miễn phí
                            </Link>
                        </small>
                    </div>

                    <button type="submit" style={btnStyle}>
                        Xác nhận đăng nhập
                    </button>
                </form>
            </section>
        </div>
    );
};

export default Login;