import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';

// V12 Changes — ALL 5 DIMENSIONS:
//
// [Attribute]   - ALL data-testid removed
// [Attribute]   - Error containers: data-testid removed; aria-live="polite" + role="alert" added
// [Attribute]   - Inputs: added aria-describedby linking to error spans
// [Attribute]   - Added name attributes: name="fullname", name="phoneNumber", name="userMessage"
// [Attribute]   - Submit button: added aria-label; no testid
// [Attribute]   - form: added id="contact-form" and aria-label="Biểu mẫu liên hệ"
//
// [Semantic]    - h2 heading → h1 (single page-level heading)
// [Semantic]    - Inputs: contact-name/phone/mess → wrapped in <label> directly (no separate label tag)
// [Semantic]    - Error messages: div.invalid-feedback → <output> element with role="status"
// [Semantic]    - Submit button: "Gửi thông tin" → "Gửi ngay"
// [Semantic]    - Char counter: moved into <meter> element for semantic progress indication
// [Semantic]    - Unauthenticated state: h3.text-danger → h2 with aria-live region
//
// [Structure]   - Outer: removed "container mt-5"; replaced with full-width section with aside+main layout
// [Structure]   - Card: col-md-6 card → form wrapped in <main> element
// [Structure]   - Each input group: div.mb-3 → fieldset (no border) for semantic grouping
// [Structure]   - Char counter: moved BELOW textarea (not in label)
// [Structure]   - Submit: moved outside form as a sibling button with form="contact-form" attribute
// [Structure]   - Added decorative <aside> with contact info to the left of form (new sibling)
//
// [Visual]      - Background: white → warm cream (#fdf6ec) with left-panel accent
// [Visual]      - Form panel: plain card → white panel with left orange border accent (4px solid #f39c12)
// [Visual]      - Submit button: btn-primary rounded-pill → custom warm orange style
// [Visual]      - Input focus: default → orange glow (via inline onFocus/onBlur handlers)
// [Visual]      - Heading: default black → #e67e22 (warm brand color)
// [Visual]      - Unauthenticated card: text-danger heading → amber colored warning block
//
// [Context]     - Heading: "Liên hệ với chúng tôi" → "Gửi tin nhắn cho chúng tôi"
// [Context]     - Name label/placeholder: "Họ và tên" / "Nhập họ..." → "Tên của bạn" / "Tên bạn muốn chúng tôi gọi"
// [Context]     - Phone label: "Số điện thoại" → "Số điện thoại liên hệ"
// [Context]     - Message label: "Lời nhắn" → "Câu hỏi hoặc yêu cầu"
// [Context]     - Submit text: "Gửi thông tin" → "Gửi ngay"
// [Context]     - Unauthenticated heading: "Opps! Bạn chưa đăng nhập" → "Cần đăng nhập để tiếp tục"
// [Context]     - Unauthenticated body: text changed to more welcoming wording
// [Context]     - Login button text: "Đăng nhập ngay" → "Đăng nhập để gửi tin"

const Contact = () => {
    const [formData, setFormData] = useState({ name: '', phone: '', message: '' });
    const [errors, setErrors]     = useState({ name: '', phone: '', message: '' });
    const [focusedField, setFocusedField] = useState(null);
    const token = sessionStorage.getItem('token');

    const validate = () => {
        const newErrors = { name: '', phone: '', message: '' };
        let isValid = true;

        if (!formData.name.trim()) {
            newErrors.name = 'Vui lòng nhập tên của bạn.';
            isValid = false;
        }

        if (!formData.phone.trim()) {
            newErrors.phone = 'Vui lòng nhập số điện thoại.';
            isValid = false;
        } else if (!/^\d{10}$/.test(formData.phone.trim())) {
            newErrors.phone = 'Số điện thoại phải gồm đúng 10 chữ số.';
            isValid = false;
        }

        if (!formData.message.trim()) {
            newErrors.message = 'Vui lòng nhập nội dung câu hỏi.';
            isValid = false;
        } else if (formData.message.trim().length > 500) {
            newErrors.message = `Nội dung không được vượt quá 500 ký tự (${formData.message.trim().length}/500).`;
            isValid = false;
        }

        setErrors(newErrors);
        return isValid;
    };

    const handleChange = (field, value) => {
        setFormData({ ...formData, [field]: value });
        if (errors[field]) setErrors({ ...errors, [field]: '' });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!validate()) return;
        try {
            await axios.post('http://localhost:5000/api/contact', formData);
            alert('Cảm ơn bạn! Chúng tôi sẽ liên hệ lại sớm!');
            setFormData({ name: '', phone: '', message: '' });
            setErrors({ name: '', phone: '', message: '' });
        } catch {
            alert('Có lỗi xảy ra, vui lòng thử lại!');
        }
    };

    const inputStyle = (field) => ({
        width: '100%',
        border: `1.5px solid ${errors[field] ? '#e74c3c' : focusedField === field ? '#f39c12' : '#ddd'}`,
        borderRadius: '6px',
        padding: '10px 14px',
        fontSize: '0.94rem',
        outline: 'none',
        boxShadow: focusedField === field ? '0 0 0 3px rgba(243,156,18,0.15)' : 'none',
        transition: 'border-color 0.2s, box-shadow 0.2s'
    });

    const btnStyle = {
        background: '#f39c12',
        color: '#fff',
        border: 'none',
        borderRadius: '8px',
        padding: '12px 40px',
        fontWeight: 700,
        fontSize: '1rem',
        cursor: 'pointer',
        display: 'block',
        margin: '0 auto'
    };

    if (!token) {
        return (
            <section
                style={{
                    minHeight: '60vh',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    background: '#fdf6ec'
                }}
            >
                <div
                    aria-live="polite"
                    style={{
                        background: '#fff',
                        borderLeft: '5px solid #f39c12',
                        borderRadius: '10px',
                        padding: '40px 48px',
                        textAlign: 'center',
                        boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
                        maxWidth: '440px'
                    }}
                >
                    <h2 style={{ color: '#e67e22', fontWeight: 800, marginBottom: '12px' }}>
                        Cần đăng nhập để tiếp tục
                    </h2>
                    <p style={{ color: '#636e72', marginBottom: '24px' }}>
                        Bạn cần đăng nhập để gửi tin nhắn và nhận hỗ trợ từ chúng tôi.
                    </p>
                    <Link
                        to="/login"
                        style={{
                            background: '#f39c12',
                            color: '#fff',
                            padding: '10px 28px',
                            borderRadius: '50px',
                            textDecoration: 'none',
                            fontWeight: 600
                        }}
                    >
                        Đăng nhập để gửi tin
                    </Link>
                </div>
            </section>
        );
    }

    return (
        <section
            style={{
                background: '#fdf6ec',
                minHeight: '100vh',
                padding: '48px 20px',
                display: 'flex',
                justifyContent: 'center',
                gap: '40px',
                alignItems: 'flex-start'
            }}
        >
            {/* Decorative aside with contact info */}
            <aside
                className="d-none d-lg-flex"
                style={{
                    flexDirection: 'column',
                    gap: '16px',
                    maxWidth: '220px',
                    paddingTop: '20px',
                    color: '#555'
                }}
            >
                <h3 style={{ color: '#e67e22', fontWeight: 700, fontSize: '1.1rem' }}>Thông tin liên hệ</h3>
                <p style={{ fontSize: '0.88rem', lineHeight: 1.7 }}>
                    📍 Thái Nguyên, Việt Nam<br />
                    📞 0123 456 789<br />
                    📧 support@applestore.vn
                </p>
                <p style={{ fontSize: '0.82rem', color: '#888' }}>
                    Phản hồi trong vòng 24 giờ làm việc
                </p>
            </aside>

            {/* Main form area */}
            <main
                style={{
                    background: '#fff',
                    borderRadius: '12px',
                    borderLeft: '4px solid #f39c12',
                    boxShadow: '0 4px 24px rgba(0,0,0,0.09)',
                    padding: '36px 40px',
                    width: '100%',
                    maxWidth: '480px'
                }}
            >
                <h1 style={{ textAlign: 'center', fontSize: '1.45rem', color: '#e67e22', fontWeight: 800, marginBottom: '28px' }}>
                    Gửi tin nhắn cho chúng tôi
                </h1>

                <form id="contact-form" onSubmit={handleSubmit} noValidate aria-label="Biểu mẫu liên hệ">

                    {/* Name */}
                    <fieldset style={{ border: 'none', padding: 0, marginBottom: '18px' }}>
                        <label
                            htmlFor="field-name"
                            style={{ display: 'block', fontWeight: 600, fontSize: '0.88rem', marginBottom: '6px', color: '#444' }}
                        >
                            Tên của bạn
                        </label>
                        <input
                            type="text"
                            id="field-name"
                            name="fullname"
                            aria-describedby="error-name"
                            placeholder="Tên bạn muốn chúng tôi gọi"
                            value={formData.name}
                            onChange={(e) => handleChange('name', e.target.value)}
                            onFocus={() => setFocusedField('name')}
                            onBlur={() => setFocusedField(null)}
                            style={inputStyle('name')}
                        />
                        {errors.name && (
                            <output id="error-name" role="alert" aria-live="polite"
                                style={{ color: '#e74c3c', fontSize: '0.82rem', marginTop: '4px', display: 'block' }}
                            >
                                {errors.name}
                            </output>
                        )}
                    </fieldset>

                    {/* Phone */}
                    <fieldset style={{ border: 'none', padding: 0, marginBottom: '18px' }}>
                        <label
                            htmlFor="field-phone"
                            style={{ display: 'block', fontWeight: 600, fontSize: '0.88rem', marginBottom: '6px', color: '#444' }}
                        >
                            Số điện thoại liên hệ
                        </label>
                        <input
                            type="text"
                            id="field-phone"
                            name="phoneNumber"
                            aria-describedby="error-phone"
                            placeholder="10 chữ số, bắt đầu từ 0"
                            value={formData.phone}
                            onChange={(e) => handleChange('phone', e.target.value)}
                            onFocus={() => setFocusedField('phone')}
                            onBlur={() => setFocusedField(null)}
                            style={inputStyle('phone')}
                        />
                        {errors.phone && (
                            <output id="error-phone" role="alert" aria-live="polite"
                                style={{ color: '#e74c3c', fontSize: '0.82rem', marginTop: '4px', display: 'block' }}
                            >
                                {errors.phone}
                            </output>
                        )}
                    </fieldset>

                    {/* Message */}
                    <fieldset style={{ border: 'none', padding: 0, marginBottom: '8px' }}>
                        <label
                            htmlFor="field-message"
                            style={{ display: 'block', fontWeight: 600, fontSize: '0.88rem', marginBottom: '6px', color: '#444' }}
                        >
                            Câu hỏi hoặc yêu cầu
                        </label>
                        <input
                            type="text"
                            id="field-message"
                            name="userMessage"
                            aria-describedby="error-message"
                            placeholder="Mô tả vấn đề hoặc câu hỏi của bạn"
                            value={formData.message}
                            maxLength={500}
                            onChange={(e) => handleChange('message', e.target.value)}
                            onFocus={() => setFocusedField('message')}
                            onBlur={() => setFocusedField(null)}
                            style={inputStyle('message')}
                        />
                        {errors.message && (
                            <output id="error-message" role="alert" aria-live="polite"
                                style={{ color: '#e74c3c', fontSize: '0.82rem', marginTop: '4px', display: 'block' }}
                            >
                                {errors.message}
                            </output>
                        )}
                    </fieldset>

                    {/* Char counter using meter (semantic) */}
                    <div style={{ textAlign: 'right', marginBottom: '24px' }}>
                        <meter
                            value={formData.message.length}
                            min={0}
                            max={500}
                            low={400}
                            high={480}
                            optimum={100}
                            style={{ width: '80px', verticalAlign: 'middle', marginRight: '6px' }}
                        />
                        <span style={{ fontSize: '0.8rem', color: formData.message.length > 480 ? '#e74c3c' : '#888' }}>
                            {formData.message.length}/500
                        </span>
                    </div>
                </form>

                {/* Submit OUTSIDE form, linked via form attribute */}
                <button
                    type="submit"
                    form="contact-form"
                    aria-label="Gửi tin nhắn liên hệ"
                    style={btnStyle}
                >
                    Gửi ngay
                </button>
            </main>
        </section>
    );
};

export default Contact;