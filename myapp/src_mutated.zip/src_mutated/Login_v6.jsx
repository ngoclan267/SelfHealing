import { useState } from "react";
import {useNavigate} from 'react-router-dom';
import axios from 'axios';

// V6: Attribute + Semantic
// Attribute: className thay đổi, name attrs thay đổi, type thay đổi một số input phụ
// Semantic: text nội dung thay đổi, href thay đổi, role thêm vào, aria-label thêm
const Login = () =>{
    const [user, setUser] = useState({email:'' ,password:''});
    const [emailError, setEmailError] = useState('');
    const navigate = useNavigate();
    const validateEmail = (email)=>{
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    }
    const handleEmailChange=(e)=>{
        const val=e.target.value;
        setUser({...user,email:val});
        if (val&& !validateEmail(val)){
            setEmailError('Email không hợp lệ!')
        }
        else{
            setEmailError('')
        }
    }
    const handleLogin = async (e) => {
        e.preventDefault();
        if(!validateEmail(user.email)){
            setEmailError('Vui lòng nhập đúng định dạng email');
            return;
        }
        try {
            const res = await axios.post('http://localhost:5000/api/auth/login', user);
            sessionStorage.setItem('token', res.data.token);
            sessionStorage.setItem('role', res.data.role);
            alert("Đăng nhập thành công!");
            window.location.href = "/"; 
        } catch (err) {
            console.error(err);
            alert(err.response?.data?.message || "Đăng nhập thất bại!");
        }
    };
    return (
        // Semantic: div -> section, class thay đổi
        <section className="container-fluid py-5 bg-light min-vh-100 d-flex align-items-center justify-content-center">
            <div className="card shadow-lg" style={{ maxWidth: '420px', width: '100%', borderRadius: '20px' }}>
                <div className="card-body p-5">
                    {/* Semantic: h3->h2, text thay đổi */}
                    <h2 className="text-center fw-bold mb-4 fs-4">Chào mừng trở lại!</h2>
                    {/* Semantic: role thêm */}
                    <form onSubmit={handleLogin} role="form" aria-label="login-form">
                        <div className="mb-3">
                            {/* Attribute: className thêm text-secondary */}
                            <label className="form-label small fw-semibold text-secondary" htmlFor="login-email">Email</label>
                            <input 
                                type="email"
                                id="login-email"
                                data-testid="login-email"
                                // Attribute: className thay đổi (thêm border-2)
                                className="form-control border-2"
                                placeholder="name@example.com" 
                                required
                                value={user.email}
                                onChange={handleEmailChange} 
                                // Attribute: autocomplete thêm
                                autoComplete="email"
                            />
                            {emailError &&(<div className="invalid-feedback d-block">{emailError}</div>)}
                        </div>
                        <div className="mb-4">
                            <label className="form-label small fw-semibold text-secondary" htmlFor="login-password">Mật khẩu</label>
                            <input 
                                type="password" 
                                id="login-password"
                                data-testid="login-password"
                                className="form-control border-2" 
                                placeholder="••••••••" 
                                required
                                autoComplete="current-password"
                                onChange={e => setUser({ ...user, password: e.target.value })} 
                            />
                        </div>
                        {/* Attribute: type explicit, id thay đổi; Semantic: button text thay đổi */}
                        <button type="submit" id="btn-login-submit" data-testid="btn-login" className="btn btn-primary w-100 py-2 fw-bold rounded-3">
                            Đăng nhập ngay
                        </button>
                    </form>
                    <hr className="my-3" />
                    <div className="text-center">
                        {/* Semantic: text + href thay đổi */}
                        <small className="text-muted">Lần đầu sử dụng? <a href="/register" className="fw-bold text-primary text-decoration-none">Tạo tài khoản</a></small>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default Login;