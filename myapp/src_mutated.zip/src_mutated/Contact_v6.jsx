import { useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

// V6: Attribute + Semantic
// Attribute: className thay đổi, input type thay đổi (message -> textarea), name attr thêm
// Semantic: text nội dung, role, aria thêm, href thay đổi
const Contact = () => {
    const [formData, setFormData] = useState({ name: '', phone: '', message: '' });
    const [errors, setErrors]     = useState({ name: '', phone: '', message: '' });
    const token = sessionStorage.getItem('token');

    const validate = () => {
        const newErrors = { name: '', phone: '', message: '' };
        let isValid = true;
        if (!formData.name.trim()) { newErrors.name = 'Vui lòng nhập họ và tên.'; isValid = false; }
        if (!formData.phone.trim()) { newErrors.phone = 'Vui lòng nhập số điện thoại.'; isValid = false; }
        else if (!/^\d{10}$/.test(formData.phone.trim())) { newErrors.phone = 'Số điện thoại phải gồm đúng 10 chữ số.'; isValid = false; }
        if (!formData.message.trim()) { newErrors.message = 'Vui lòng nhập lời nhắn.'; isValid = false; }
        else if (formData.message.trim().length > 500) { newErrors.message = `Lời nhắn không được vượt quá 500 ký tự.`; isValid = false; }
        setErrors(newErrors);
        return isValid;
    };

    const handleChange = (field, value) => {
        setFormData({ ...formData, [field]: value });
        if (errors[field]) setErrors({ ...errors, [field]: '' });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!validate()) return;
        try {
            await axios.post('http://localhost:5000/api/contact', formData);
            alert('Cảm ơn bạn! Chúng tôi sẽ liên hệ lại sớm! ^^');
            setFormData({ name: '', phone: '', message: '' });
            setErrors({ name: '', phone: '', message: '' });
        } catch (err) {
            alert('Có lỗi xảy ra, vui lòng thử lại!!!');
        }
    };

    if (!token) {
        return (
            <div className="container mt-5">
                <div className="card p-5 text-center shadow-sm border-0 rounded-4">
                    <h3 className="text-danger fw-bold">Opps! Bạn chưa đăng nhập</h3>
                    <p className="text-muted">Vui lòng đăng nhập để sử dụng tính năng gửi liên hệ.</p>
                    <div className="mt-3">
                        {/* Semantic: href thay đổi thành /auth/login */}
                        <a href="/auth/login" className="btn btn-primary px-4 rounded-pill">Đăng nhập ngay</a>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="container mt-5">
            <div className="row justify-content-center">
                {/* Attribute: col-md-6 -> col-md-7 */}
                <div className="col-md-7 card p-4 shadow rounded-4">
                    <h2 className="text-center mb-4">Liên hệ với chúng tôi</h2>
                    {/* Semantic: role thêm */}
                    <form onSubmit={handleSubmit} noValidate role="form" aria-label="contact-form">
                        <div className="mb-3">
                            <label className="form-label fw-semibold" htmlFor="contact-name">Họ và tên</label>
                            <input
                                type="text"
                                id="contact-name"
                                data-testid="contact-name"
                                name="fullname"
                                placeholder="Nhập họ và tên của bạn"
                                className={`form-control border-2 ${errors.name ? 'is-invalid' : ''}`}
                                value={formData.name}
                                onChange={(e) => handleChange('name', e.target.value)}
                                autoComplete="name"
                            />
                            {errors.name && <div className="invalid-feedback" data-testid="error-contact-name">{errors.name}</div>}
                        </div>

                        <div className="mb-3">
                            <label className="form-label fw-semibold" htmlFor="contact-phone">Số điện thoại</label>
                            <input
                                type="tel"
                                id="contact-phone"
                                data-testid="contact-phone"
                                name="phone"
                                placeholder="Nhập số điện thoại (10 chữ số)"
                                className={`form-control border-2 ${errors.phone ? 'is-invalid' : ''}`}
                                value={formData.phone}
                                onChange={(e) => handleChange('phone', e.target.value)}
                                autoComplete="tel"
                            />
                            {errors.phone && <div className="invalid-feedback" data-testid="error-contact-phone">{errors.phone}</div>}
                        </div>

                        <div className="mb-3">
                            <label className="form-label fw-semibold" htmlFor="contact-mess">
                                Lời nhắn
                                <span className="text-muted ms-2" style={{ fontSize: '0.85em' }}>({formData.message.length}/500)</span>
                            </label>
                            {/* Attribute: type text -> textarea (semantic change in element type) */}
                            <textarea
                                id="contact-mess"
                                data-testid="contact-mess"
                                name="message"
                                rows="3"
                                placeholder="Nhập lời nhắn của bạn (tối đa 500 ký tự)"
                                className={`form-control border-2 ${errors.message ? 'is-invalid' : ''}`}
                                value={formData.message}
                                onChange={(e) => handleChange('message', e.target.value)}
                            />
                            {errors.message && <div className="invalid-feedback" data-testid="error-contact-mess">{errors.message}</div>}
                        </div>

                        <div className="d-grid mb-3">
                            <button type="submit" data-testid="btn-contact-submit" className="btn btn-primary rounded-pill fw-bold">
                                Gửi thông tin
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default Contact;