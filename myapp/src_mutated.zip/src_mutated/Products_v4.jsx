import { useState, useEffect } from "react";
import axios from 'axios';
import { Link, useLocation, useNavigate } from 'react-router-dom';

// V4: Visual only - horizontal list cards, filter as select dropdown, search with icon
// data-testid prefix "v4-"
// UNCHANGED: text labels/button, id, name, placeholder, structure logic, context

const Products = () => {
    const [products, setProducts] = useState([]);
    const [allProducts, setAllProducts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState("");
    const navigate = useNavigate();
    const location = useLocation();
    const typeFromUrl = new URLSearchParams(location.search).get('type') || "Tất cả";
    const [activeCategory, setActiveCategory] = useState(typeFromUrl);
    const [role, setRole] = useState(sessionStorage.getItem('role'));

    useEffect(() => { setRole(sessionStorage.getItem('role')); fetchProducts(); }, []);
    const fetchProducts = () => {
        setLoading(true);
        axios.get("http://localhost:5000/api/products")
            .then(res => { if (Array.isArray(res.data)) { setAllProducts(res.data); applyFilter(res.data, activeCategory); } setLoading(false); })
            .catch(() => setLoading(false));
    };
    const applyFilter = (data, cat) => setProducts(cat === 'Tất cả' ? data : data.filter(p => p.category === cat));
    const handleFilter = (cat) => { setActiveCategory(cat); applyFilter(allProducts, cat); };
    const handleDelete = async (cat, id) => {
        if (!window.confirm("Bạn có chắc muốn xóa sản phẩm này?")) return;
        try {
            await axios.delete(`http://localhost:5000/api/products/${cat}/${id}`, { headers: { Authorization: `Bearer ${sessionStorage.getItem('token')}` } });
            alert("Xóa thành công!"); fetchProducts();
        } catch (err) { alert(err.response?.data?.message || "Lỗi khi xóa"); }
    };

    const searched = products.filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()));
    if (loading) return <div className="text-center mt-5">Đang tải sản phẩm...</div>;

    return (
        <div style={{ backgroundColor: '#ffffff', minHeight: '100vh' }}>
            <div className="container py-5">
                <h2 className="mb-5 fw-bold" style={{ fontSize: '32px', borderLeft: '4px solid #007bff', paddingLeft: '16px' }}>Khám phá sản phẩm</h2>
                <div className="row align-items-center mb-5 g-3">
                    <div className="col-md-7">
                        <div className="input-group">
                            <span className="input-group-text bg-white border-end-0">🔍</span>
                            <input type="text" id="search-input" data-testid="v4-search-input"
                                className="form-control border-start-0 ps-0"
                                style={{ boxShadow: 'none' }}
                                placeholder="Tìm kiếm sản phẩm (Viết đúng chính tả...)"
                                value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
                        </div>
                    </div>
                    <div className="col-md-3">
                        <select className="form-select" data-testid="v4-filter-select"
                            value={activeCategory} onChange={(e) => handleFilter(e.target.value)}>
                            {['Tất cả', 'iphone', 'ipad', 'macbook', 'airpods'].map(cat => (
                                <option key={cat} value={cat}>{cat.toUpperCase()}</option>
                            ))}
                        </select>
                    </div>
                    {role === 'admin' && (
                        <div className="col-md-2">
                            <Link to="/admin/add-product" data-testid="v4-btn-add-product" className="btn btn-success w-100">+ Thêm sản phẩm mới</Link>
                        </div>
                    )}
                </div>
                <div className="d-flex flex-column gap-3">
                    {searched.length > 0 ? searched.map(p => (
                        <div key={p._id} className="card border-0 shadow-sm" style={{ borderRadius: '8px' }}>
                            <div className="row g-0 align-items-center">
                                <div className="col-3 col-md-2">
                                    <img src={p.image || (p.variants && p.variants[0]?.img) || "https://via.placeholder.com/150"}
                                        className="img-fluid" alt={p.name}
                                        style={{ height: '100px', objectFit: 'contain', padding: '10px' }} />
                                </div>
                                <div className="col-5 col-md-6 px-3">
                                    <h6 className="fw-bold mb-1">{p.name}</h6>
                                    <span className="badge text-bg-light text-capitalize">{p.category}</span>
                                </div>
                                <div className="col-4 col-md-4 text-end pe-3 d-flex flex-column align-items-end gap-2">
                                    <span className="fw-bold text-danger">{Number(p.pr || p.price).toLocaleString()} VND</span>
                                    <Link to={`/product/${p.category}/${p._id}`} data-testid={`v4-btn-view-${p._id}`}
                                        className="btn btn-sm btn-dark px-3" style={{ borderRadius: '4px' }}>Xem chi tiết</Link>
                                    {role === 'admin' && (
                                        <div className="d-flex gap-1">
                                            <button onClick={() => handleDelete(p.category, p._id)} data-testid={`v4-btn-delete-${p._id}`} className='btn btn-sm btn-outline-danger px-2'>Xóa sản phẩm</button>
                                            <button data-testid={`v4-btn-edit-${p._id}`} className='btn btn-sm btn-outline-warning px-2' onClick={() => navigate(`/edit-product/${p.category}/${p._id}`)}>Sửa</button>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    )) : (
                        <div className="text-center py-5"><p className="text-muted fs-5">Không có sản phẩm nào trong danh mục này.</p></div>
                    )}
                </div>
            </div>
        </div>
    );
};
export default Products;