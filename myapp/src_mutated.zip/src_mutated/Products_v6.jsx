import { useState, useEffect } from "react";
import axios from 'axios';
import { Link, useLocation, useNavigate } from 'react-router-dom';

// V6: Attribute + Semantic
// Attribute: classNames updated, input type, aria attributes added
// Semantic: button texts, link texts, heading texts, role attributes changed
const Products = () => {
    const [products, setProducts] = useState([]);
    const [allProducts, setAllProducts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState("");
    const navigate = useNavigate();
    const location = useLocation();
    const queryParams = new URLSearchParams(location.search);
    const typeFromUrl = queryParams.get('type') || "Tất cả"; 
    const [activeCategory, setActiveCategory] = useState(typeFromUrl);
    const [role, setRole] = useState(sessionStorage.getItem('role'));

    useEffect(()=>{
        setRole(sessionStorage.getItem('role'));
        fetchProducts();
    },[]);

    const fetchProducts = () => {
        setLoading(true);
        axios.get("http://localhost:5000/api/products").then(res=>{
            if (Array.isArray(res.data)){
                setAllProducts(res.data);
                applyFilter(res.data, activeCategory);
            }
            setLoading(false);
        }).catch(err=>{ console.error("Lỗi kết nối!", err); setLoading(false); });
    };

    const applyFilter = (data, category) => {
        setProducts(category === 'Tất cả' ? data : data.filter(p => p.category === category));
    };

    const handleFilter = (category) => { setActiveCategory(category); applyFilter(allProducts, category); };

    const handleDelete = async (category, id) => {
        if(window.confirm("Bạn có chắc muốn xóa sản phẩm này?")){
            const token = sessionStorage.getItem('token');
            try {
                await axios.delete(`http://localhost:5000/api/products/${category}/${id}`, { headers:{Authorization:`Bearer ${token}`} });
                alert("Xóa thành công!");
                fetchProducts();
            } catch(err) { alert(err.response?.data?.message || "Lỗi khi xóa"); }
        }
    };

    const searchedProducts = products.filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()));
    if (loading) return <div className="text-center mt-5" role="status" aria-live="polite">Đang tải sản phẩm...</div>;

    return (
        // Attribute: container -> container-lg
        <main className="container-lg mt-4" role="main">
            {/* Semantic: h2 text thay đổi */}
            <h2 className="mb-4 text-center fw-bold text-dark">Tất cả sản phẩm</h2>
            {role === 'admin' && (
                <div className="text-center mb-4">
                    {/* Semantic: link text thay đổi; Attribute: class thêm fw-bold */}
                    <Link to="/admin/add-product" data-testid="btn-add-product" className="btn btn-success rounded-pill px-4 shadow fw-bold">
                        Thêm sản phẩm mới
                    </Link>
                </div>
            )}
            <div className="row justify-content-center mb-4">
                <div className="col-md-6">
                    <input 
                        type="search"
                        data-testid="search-input"
                        className="form-control rounded-pill px-4 shadow-sm border-2"
                        placeholder="Tìm kiếm sản phẩm..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        aria-label="Tìm kiếm sản phẩm"
                    />
                </div>
            </div>
            {/* Semantic: nav role thêm */}
            <nav aria-label="Bộ lọc danh mục" className="d-flex justify-content-center gap-2 mb-5">
                {['Tất cả', 'iphone', 'ipad', 'macbook', 'airpods'].map(cat => (
                    <button 
                        key={cat}
                        data-testid={`btn-filter-${cat==='Tất cả'? 'all':cat}`}
                        onClick={() => handleFilter(cat)}
                        aria-pressed={activeCategory === cat}
                        className={`btn rounded-pill px-4 ${activeCategory===cat ? 'btn-dark' : 'btn-outline-dark'}`}
                    >
                        {cat.toUpperCase()}
                    </button>
                ))}
            </nav>
            <div className="row g-4">
                {searchedProducts.length > 0 ? (
                    searchedProducts.map(p => (
                        <div className="col-sm-6 col-md-4 col-lg-3" key={p._id}>
                            <article className="card shadow-sm h-100 border-0 rounded-4">
                                <img 
                                    src={p.image || (p.variants && p.variants[0]?.img) || "https://via.placeholder.com/150"} 
                                    className="card-img-top" 
                                    alt={p.name} 
                                    style={{ height: "180px", objectFit: "contain", padding: "15px" }}
                                />
                                <div className="card-body text-center">
                                    <h6 className="card-title fw-bold">{p.name}</h6>
                                    <p className="text-danger fw-bold mb-2">
                                        {Number(p.pr || p.price).toLocaleString()} VND
                                    </p>
                                    {/* Semantic: link text thay đổi */}
                                    <Link to={`/product/${p.category}/${p._id}`} data-testid={`btn-view-${p._id}`} className="btn btn-outline-dark btn-sm rounded-pill w-100">
                                        Chi tiết sản phẩm
                                    </Link>
                                    {role === 'admin' && (
                                        <div className="d-flex gap-2 mt-2">
                                            <button onClick={() => handleDelete(p.category, p._id)} data-testid={`btn-delete-${p._id}`} className='btn btn-danger btn-sm rounded-pill flex-fill'>
                                                Xóa
                                            </button>
                                            <button className='btn btn-warning btn-sm rounded-pill flex-fill' data-testid={`btn-edit-${p._id}`} onClick={() => navigate(`/edit-product/${p.category}/${p._id}`)}>
                                                Cập nhật
                                            </button>
                                        </div>
                                    )}
                                </div>
                            </article>
                        </div>
                    ))
                ) : (
                    <div className="text-center w-100 mt-5">
                        <p className="text-muted fs-6">Không tìm thấy sản phẩm nào.</p>
                    </div>
                )}
            </div>
        </main>
    );
};

export default Products;