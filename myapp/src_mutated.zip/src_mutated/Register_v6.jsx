const Register = () => {
    const [user, setUser] = useState({ email: '', password: '', role: 'user' });
    const [emailError, setEmailError]=useState('');
    const navigate = useNavigate();
    const validateEmail = (email)=>{
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    }
    const handleEmailChange=(e)=>{
        const val=e.target.value;
        setUser({...user,email:val});
        if (val&& !validateEmail(val)){
            setEmailError('Email không hợp lệ!')
        }
        else{
            setEmailError('')
        }
    }
    const handleRegister = async (e) => {
        e.preventDefault();
        if (!validateEmail(user.email)){
            setEmailError('Vui lòng nhập dùng định dạng email!');
            return
        }
        try {
            const res = await axios.post('http://localhost:5000/api/auth/register', user);
            alert(res.data.message || "Đăng ký thành công!");
            navigate('/login');
        } catch (err) {
            console.error(err);
            alert(err.response?.data?.message || "Đăng ký thất bại, email có thể đã tồn tại!");
        }
    };

    return (
        // Semantic+Attribute: section wrapping, bg thay đổi
        <section className="container-fluid min-vh-100 bg-light d-flex align-items-center justify-content-center py-5">
            <div className="card shadow-lg" style={{ maxWidth: '420px', width: '100%', borderRadius: '20px' }}>
                <div className="card-body p-5">
                    {/* Semantic: h3->h2 */}
                    <h2 className="text-center fw-bold mb-4 fs-4">Đăng ký tài khoản</h2>
                    <form onSubmit={handleRegister} role="form" aria-label="register-form">
                        <div className="mb-3">
                            {/* Attribute: className thêm fw-semibold */}
                            <label className="form-label small fw-semibold text-secondary" htmlFor="register-email">Email</label>
                            <input 
                                type="email" 
                                id="register-email"
                                data-testid="register-email"
                                className="form-control border-2" 
                                placeholder="name@example.com" 
                                required
                                autoComplete="email"
                                value={user.email}
                                onChange={handleEmailChange} 
                            />
                            {emailError&&(
                                <div className='invalid-feedback d-block text-danger small'>
                                    {emailError}
                                </div>
                            )}
                        </div>
                        <div className="mb-3">
                            <label className="form-label small fw-semibold text-secondary" htmlFor="register-password">Mật khẩu</label>
                            <input 
                                type="password" 
                                id="register-password"
                                data-testid="register-password"
                                className="form-control border-2" 
                                placeholder="Tối thiểu 8 ký tự" 
                                required
                                autoComplete="new-password"
                                onChange={e => setUser({ ...user, password: e.target.value })} 
                            />
                        </div>
                        {/* Semantic: button text thay đổi */}
                        <button type="submit" data-testid="btn-register" className="btn btn-success w-100 py-2 fw-bold mt-2 rounded-3">Tạo tài khoản</button>
                    </form>
                    <hr className="my-3" />
                    <div className="text-center">
                        {/* Semantic: text thay đổi, Link to giữ nguyên */}
                        <small className="text-muted">Bạn đã có tài khoản? <Link to="/login" className="fw-bold text-primary text-decoration-none">Đăng nhập</Link></small>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default Register;